


const WEBHOOK_URL='https://n8n-mzbmiib3etk4.kangkung.sumopod.my.id/webhook/fortuna-v5';
const PACKAGES=['CUCI KOMPLIT REGULER','CUCI REGULER','SETRIKA REGULER','EXPRESS 1 HARI','CUCI EXPRESS 1 HARI','SETRIKA EXPRESS 1 HARI','EXPRESS 3 JAM','CUCI EXPRESS 3 JAM','SETRIKA EXPRESS 3 JAM','EXPRESS 6 JAM','CUCI EXPRESS 6 JAM','SETRIKA EXPRESS 6 JAM','FLEKSIBEL'];
const DURATION={'CUCI KOMPLIT REGULER':72,'CUCI REGULER':72,'SETRIKA REGULER':48,'EXPRESS 1 HARI':24,'CUCI EXPRESS 1 HARI':24,'SETRIKA EXPRESS 1 HARI':24,'EXPRESS 3 JAM':3,'CUCI EXPRESS 3 JAM':3,'SETRIKA EXPRESS 3 JAM':3,'EXPRESS 6 JAM':6,'CUCI EXPRESS 6 JAM':6,'SETRIKA EXPRESS 6 JAM':6,'FLEKSIBEL':0};
let orders=[],draft=null,payOrder=null,printer=null,busy=false,numTarget=null,statusFilter='ALL',deadlineItems=[],deadlineFilter='ALL',opsView='new',previewMode='create',previewOrder=null,waTarget=null;
// Isi URL halaman status customer yang sebenarnya di sini saat sudah tersedia. Jangan gunakan URL dashboard internal.
const STATUS_CHECK_BASE_URL='https://fortunasortir.beuna.xyz/customerdash.html';
const FORTUNA_LOGO_PNG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYAAAAHCCAYAAADmVx7YAAAeL0lEQVR42u3d2W4zObJFYTuh939l9UW3C26XLZFMDhHkt4AGzqlfljI57B3B8fP5fD4/APwfn5+fXb5H90JkHooAOwtwhPdgAmAAwAGC/+rdGAGicSkCEH+AAQBIYphME13akklgiP7n0drdSspJV0Yt5gBwNKNEs6exlX7X988xAzAAEOZDMyRmAAYAJDa1XlkEM8BfmAQGgkfzvZ/BBDIYAP4lCoRh/6yCEeA7hoBEpFVRqiGE+WJd+r0tgm6nMgPA4aLf+veEY4zYltbRz+/6+f/Xrh5SnwwARL/6ewlH3IzDMA8YANGf8luMIF69fa+Td99tOIgBAIwgSXQ/0gzAAHBw9GhiEWAAOED4X4n1b/9W8ntM4Lx2pr4ZAJII/53OWpodZDeBd0Naq4ZRVpRpqekzAwaAoJF+7445cpXJynf9+du7jZf/9T49jY4Z5MBO4EPE//l8DumIo753JaM3bI00vYhGbNexDADJo/3WbMBcQF/xv1uWtdH/yDatXcgA0Dla+orIV3SuliGEE0SA0OXJeGQAEO2D+Fe+3917C7RfBkD4NxCXlqGg2g1Kd0Una3lHHv5pPYeopH2AAeCQqJIIyAzAAET/hBETov/Rz+QsotiYBE7Q8bN1imgbp3YLBmaJ+IiD6XZcNiwDQKhoD8Q/eht1VDUDQADxz7w2+xQRiXr0w4nGxwCwdeRpWd45da2OYQ7goCGBHS9/nyliK8ot6lJfhiQDwMZmYkWG6B8yACyIonodwAX0bjuMgwEAmJCh7Si2MhIGgM0bvU6etx5E/wwACaLDU81F/QoMwABkAbIT7YIpgQGIEnuLyB3xEeXtGW2rvz2xDBQ6uLrY5l3NYcgAdPjK7+71+4YQYpRTxMnfCBsc3U0sA0gpFr0NYoThiLyQxUxtcpQBHJkFrDqKV9QVuywiZiSjn1ubZAAMhgkcYzC73dFgtzwDEDUmM5jTO1zNfce7PE/0VWGnt0kGIErv+vzv3uHkDhepfjPXQ+/rVE9ukwxAFjBd6KTeOYxnh4nS7/Nf2uS/sQqoslGM7hS73HL17j1cPLN/MNH7d+5G/tqkDOBtA/tqBK9uzBLB9osgTytLk/FtZdBr2EebZABvRb2kAXzffMIUmECvMhlRFi3fGWmStveYvzbJAIYId6/vW7Vkb9T3l04OM9F9Iv8eq39GGpcFC//loSOM/Y0RZ530/M6f5TFyl+Qu8xvafsxnNZ8kAwgXYUbtdK/KY2U0LhMYkz1GENLS750p/qebxhEGsFpQRoxjZhYoY7B7G8jsIxruPvOrNrl7O9x+CGhkg6r97l7DK7MOsxq5LK5kOOjUQ7vuvnfWoTbDPjKAZQ3qKwqoaVDf/2aEaaw+Jnp0FHRy5x09Adnalkf1uRHvS/xlAKFEtjTy6hFZz46OR/1eyeacHuV06pDSV9lFPpOH+DOA6Y1p9ERXqRFkasirTOBuW4gq/qPNL4pgzt73gHK2GgJaLf4jUuoow0A6LCK0jVV3WjCADRrfisbTYwNUtBUKvX6312a8WXU6Kvu52z5OEn8wgGbxj5gCnxbt1Yp+zc7Oneswa+bVa/iH+DOA1B0j6rbzuxOsMyP9VSIRxVwibyo8td+m189n4jeMHvm3PHPLcM/oW5tWDFGdHPG1lne05+3RLlbfkMYAiP/xJlAzXJNlPH+HrDb6Es7fni/ysE+JAUS/4rKWx64dJHKFzFz+1zMNLtm5S/THt4+f5b2i/FqCmOwryEouk8nWnq+dKiFTBbQ84+qO3nvTnCV9fep69kqh0UNUEdtFTflmOtDwOrnjRH7W2Q1o5lJKoj+mTmZMtmebn8hiGgxgkwLd2bDuPC/hn5spjTCC0ad8Rm0js083ncljp44yupJXTEqVXmzdY96gdOy5dmIY/dp4ywm0rfXR6wjz03ePRz7yJc0qoJGpZ4Sz+mtWF6xcEgoZcU3byDJn1+sq15F9cwTXDg19pviP6ngRoifn/JyV9WpPc+siYnkcfyl8xsbd+05g1zDmFp5VRtDjJq0dMsvv75Dtovlrp8KfLd4RTaD2eIZTOukpRhDhpNtTxT+jCVy6zr3G2bMyRw8DtUT7xJ8Z1GQbK8Q/4jlaWUzgkb2h924sf6VzmXbu/nweO3QFMqX9YcZ82u7i//0z0XUjvAHMrOB3jp7NBGYaK84Jooh/3V3LkXXjOr3h1jr66Aa5ajWQoxlA/Me8Q+ThoEtDrXf0DBlLrfADmQK2bO8Q9f1NAg+ozAwmQPgxKxIfsWw5o4FF7G8PTfheZUaYza85wgHIGvVnvDWvta/KAIJFMRk6218NVbQPfdR7bJMB3Bn2mFUBq2b3CT0iiV2P9ji6z846/8pREBs6M8EF9o/cdy2H4wyAYANz+1Or+K08o2rmklX7AIK4aeRD0RgXToqAdzpsMXK/NgQUzDCkzNg1q87Qtk8S/2MNoNdphgDK+lRN31p1H/Zp4i8DuBHdMwmgTdgi9qsTxT+FAYwsrNbjbUdtunIdI041gXcB17t9LpECxyzinzoDmH1VopuzgHmZwI6a5E7gQ7IMETtQbgKtkT/xP8QAZhyR3KuhtX6H4R8IrnK2/aziLwMI0mANK0GfIv4MIIh4Rmmwon+caALEnwFUFeZKE7g7dCT6x0km8K6v7BL0ZHkP9wEsrMR3k1/A7v3qqw9kau87RP7pMgCiCJyZFWTKlrNp1JAM4HtFjVhi+Wpz1g7jh4wOEPmnM4B3u2YJG/EHiH8crtmF2GM37bsJ4cipoklfYC/xz8y1qpBGmoAoAsCsPpu5316rC/dOxJ7pSGfiD+SKwk/I1h9RCqp1EvfVRe8RJoZHnRwKQMCWOgN4lRXs4OTEH9iPnfrsbQMoOcmv59n4rRUy2wSIP5Az8j9poca0ncC/7f4b8f3vbhuaIbrEHxD5H5EBtBTW6jH5UQ5f+t3EH5gbcM38nlRl97yhRj03NPU+D7+0Mu+Kce+hKgDzs+pTN2deGSq+xZlrzhdp+Y3avyH+wJgRhbsR/MmbM5szgBnRf4/vX125hB+Ylwn01J4T+u7VuxJmTbLWDPGsqkjiD8QdMXAsS0MGMNOBewvtrAon/MC6LKCkH87Y6PXbb8zSquLf2cEAVv4u4QdymcBI8Y+UVRTNm/Q0gNEbvqIaAeEH4hpB7R6kkj1FWXinTY/oldf6nTV3+pY+F6EHcprEqzPDIkfxw8umJgNYNfxTU3kEG5AFoEwHrxk/0qPSWlbzaBjA2QKH1zr46PElIyvg53ePPlMIQE4TOGHMvnfQu2QOoPfKnwgHwAFgAtmykiID6FmoI45P2GnWHsDYoPA3wzg1SLx6FTgARDOCks/tpGF/vctfhnjt8uKWbgLAxAxg5Kocwg0AY4Pkq+WPskT/AM7lXRC5q27UBM9XawHNXPq5+nsAYAcT+Knp0+YAROkAZAGxuLJH/yZ/ARgJaNPMa4Yriv4BZBDE04zvGvGlqyuO4wMQgL4vkytS4RNuACsi4VPf/THaLUvP53DSJ4BVQeiqM8N6XG95h6oMoPUhZhasLALASDG++xvf/7dSEz8/P8tPA70rrD0PbBP9A6jRnlWaEf3K2cdsYf3tPH8bvwDM0J0WjWvVqQz3jT8iVArxBxCBnneL3Mk8ZunZVfLiGZZ+zhxTA5A7ExhhEBGD2Ve6+Hw+cx0HXTqbDwARAtrajKG3+BdnABmi/0guDeBME9jhhOSv9792rWAmAGBmxB3lOUrF/+Nj8STwChMwWQzgL00YETi+mgzurUc14v/x8fHx+fzff8kyCdyrkhgBgJ5iujoYbXneq/SLIw2pfKVMRBzAjMzgbiD687siiH+xAfw0gohmsCKLAIDexjIzU7laHyqagLYYARMAED1YHSX+/8oAWgR0l4wAADLRY47in0ngXhFyRPHNNMENIJfYRjxGuvSZrt5iLisAwBzii//HR8E+gDtrZHuf9gkAO4v7TPEvMoDfvjyjEZjwBZBZL3qL/8fHmzmAUYU02wjMAQDIqmsjrtRtygBe/WhNoUUZGiL+ALKPFNzRsWvlQzjDH8AOjAgmS/Tx7u9evQshmhHMOoQJAPGfmYn0+N3H6ALJODQEAKvEf+ZvPmY9bIsR3H1Z0T+ATMI/esjnJ9fMAnNoG4Dswr6L+H983FwGOvqF7xSC6B/AKF2Kdqhb+AygV1Zg5RCA1VnADuK/3ADuvOArI2AQAFZnCdHFP4wBfM8GRmYEhn8ARDGB1eL/8RH0Uvi7K4cAYLYGZRP/UBnAq6ygZ4UCQOTMYaZWXRkKzHn+AIj/oQbACACs0pw7gh5Z/D8+Fu8DmOGqDAPA6sg9qkZdO1TOXwVI/AGsNo7IC1QeuxQ0sQewUuhbNGi1bl2qDgD6CvWMs/wZAAAEzAaiR/7/POvT2AkAdBP3DMIvAwCAw2EAADA4go+6h4kBAEBA02AAABBQ0EtFPfoUKwMAgAFGkGF9zUM1AsA9I/iidUOYDAAANjIDBgAAYAAAAAYAAGAAAAAGAABgAAAABgAAYAAAAAYAALjNkKMg7tyIU3Phws8t2C2/V/L3v/3t98///PdX/9byudLnLi3Tks/d+Uzr578+27uuZpf3u8+2tI/Wd33VNlv7V2sZv/uO1nodrUl3+tTd3+/RZkNmAL/dmdl6207J3726o/Pd39/992j89rylZXinXF59/vu/vaqnkt9sfb+e7e7O75W8Z+m79njv1n5a89sR+lhNua/4/RG/e0UUo5m/N6Ixn1KWLb850uTvRGhY19ai9cGW38kWBA4dAnrV8VpT0J6/+erEvlfDStlO+uvZMFc28L9+u2YIMHt9fb3rXxF/S7uM2pZn1OsdXRr92zN15lpZudF+8+fn3v3/uzL6PXtcrP1b3azs1KPK5ed7/XUGfYbsr+U7ZvW5lX175W9bBVTYATNESzv+Zu1Qzk4mXXPZSNb3LnnuSH1w9hj9dgYQvZBKJ4IyDyfU1sOICbqRZfybYGRodxmFcfbkerQ6yh5wPFY3kNZlcL2WbD2fz5crKWYsP/v6XI/G9Nf3/PWetR3u67tffd+rv/25QqXmnVvqPPpwVtQA4V32caceS9rm6OWPkepx5W8vvRJyVMXeFaYVQjKjkbeI9l3jGW18pe8z8t2jCMXMaLR3ec7ugyv7QaR6vCI36FFDA7X/Fj3S6zkpWDOROnvlyS5DczvSo24i9MHSSfafowiZAsGpGcC7wixdkjlbTHstt4tgKj12Xffu6L02K61e+dOzbGvKrUcEfrd/9azH0j64k+FF0LslGcCM4ZQ7cwQt35Glcd4tl16ftzGrrSyjtctez1LaB3uazKoh6O+T96sn8q/Ijb1343w12Wt4IYcoz9pJHL3sd1qptrIP1p5ntVv9XBE6cRThiVRptctRZ00iv4taej/zyIyltaxniVGPVVvZAoeaCdIR9VazqCBCBH+X5ctARw9l1C5Zi9C5IkYPr+Zp7o7hl3T6u2PNJb8T8aiPkW1h5Ombd+qlZeixtwm1zEtmXGmWdifwKGNZkS726uh/rf/PUr6nmepK4e1dXnf3Aaysz9EBYeS2d61u7LOGLu4+Q+t5QhE7fk+j6PHsNbteWz/Te7hpdb+IOOwwsg3drdsVdd97/8KQZ3xajhE2UlU1yludPLept4hDjA/NDcAumYT3qsNpoBoLlDdOzbYMAQHAmcgAAIABAAAYAACAAQAAGAAAYCPsAwCADkQ95JIBAMAk4X/33yMZgyEgAOgs/r3/hgEAQHLxj2YCDAAAEkfxDAAAJgl/L/GPYCIMAAAOivoZAABMIvKdwQwAAA4lzT6A39IvJ1kDiB79v9O1lToW3gBejbv1vnMTAGp1qFX8I3DtUOg7Ts4A2Ev8S+43ZgBEHQAdOtMAWtfZ9lyfCwCtvBr6iZYFhDIAAg4gsx5lm4+8shX2uzW1TAQA8U9kADXiX1LYTADATLKuRFxuACVi3bKTjgkAmBX99zCLFZr1iF7QJRMqry5ksEcAwCjBz64v16oCvyv+AJCVKFnAdANoGe+/81lDQQAQwABGiD8TADAyKmcAk8R/5LGpTADAO92ZudgkguFMMYBZ4/3mDAD0NIQVweXMYHWoAayY7DUUBKCnEYwMLFcHrUMMoEb4RxSATABAZk2ZFaxepxQoANCsgQYQZX2/oR4AM01gxGTwDB3rshN45PJO4g8gAxlPHrh6vHSkCgCAFVlARm5lANkif/MOAEbqRbYs4DGyAIk/gGzC/+qzo3Tk+Xz++nujDeUxshAjTPYSfoDgR/2+1VnFNaIARm+eIP4AdmOFXhVnAJmifuIPYNWikEzzAFfPgowS9RN/ACeaT/cMwHg/gBME+Df9mC3kf00GTzcAq3wAnCz+NboyWrS/vr+3zt3aB0D8Aewq/tG08Ov9ev7WtcLNSl+U+AM4jXea1lOfHxEjbsIPIILYRs50ejz75/N/32KyF0BWVg39RHinO+9x1RQW8QdA/GNlJ3eGhD6fz+fz3RfY3AWA+Md+z5b3ulYXFvEHMEv8s1Kify3l8fnx8fFcKbqrsw8Aov+d3rvmHa9VBVKyzJP4AyD+/bX1HwNYkWKZ7AUwk530pHRBTonOFi0D7VV4xvsBzIr4T9CUu8H0I1oFEn8APUcfdtaUr3d7VV6vNo39kwGMzgJ2H+8fdVgTQPzHiucJ5VZkACNNYEcDMIkN5BT/nQ3krzL89bjr5y//dYUJZBNLQ1rAueIf2SRqDOAxuzD+erhM16jVVgYTAM4T/1oxXvJ8zz+eZNV8QBaxrG2wTAAYJ/6jdspmyw5qDedPAxgp1NnHzlsbEhMA1q/wiWQEPTWhyySwTGB8w2EEIP7r+1BpIDrDMFZp6VsDkAmMawCMAMQ/X9Q86t1WLLC5bQCrHjxig/3+vFYJATky51kaNOIInLvafK0s+LfutHCsrua3fzubo+d5HcDp7KBBs/Wg5PeuaIUUQSBrxb9HpTMCiP73z5JLAsNSPeiRuVy9KuJORb8rlJniWDN0U1rIM652AyKJfi/hnyX+s03mbjbQSyuung+eOROoabQtjYUJ4LSI/25QuCI6n9knRw0JVV0IE0moV22b7jnk0yOiMSSE7OKfKRrPllH1nLS+olVQ1EnhnumobAAY28eymE/NO78LDIdcCh9NqHt891dBrlyqGaGxA1H65a67/6O/f9E+gNaCibZJLOr5PY6Vxqnin2nH/4xnnX3X8XVKw4h8eJtsAMAKQ3z0eODW68jufHfN986a5AVE/nP72G/PkL0P15xBdPddr54PHC0TmLnCBzhF9O+sUuvVx149wy6LJ3psMh2eAZRmAtEjE+IPjIn4R4h/yWd26NOj3+HR+2F73/hV2+h2u6iFMSG7+M8Ufiw0gN4mUFPh2aP+nu/KNLBbAEP8x3DN/sHSihwpcruvurGTGMRfJr4kA3iXBfQW/yhDPrPGHFsyBRkBCL9M49f3fQ5Uh9pNYrXLniKs8Pn5DD3nOVrL6MRIBjEEcvYFKj2fY8ayy2gMHQKqOS4io/hn7cCGhwD95+Nj0BDQT/F9Nym8Q+SfzWh23EADzGrHuwyvDh0CGpHKRbhrt/dZITViPCP6YAT7Ra096z7qMNDKuYesfWaKAdwRrtoJ5RXCH8EA7kyMM4GzRb+lLUQzgRHt9QQjmGYArW5+ovjfNYCTIxrCP+/Y4ggmEOXE3qz9Z+o+gNo7dLOIf3Ra9j2YKM4l+rMmJ7//xkmXt7T0nwwTxlMzgBJxqRX/CMK/OvpvfYYeEZy9BvtG+z0CtVFZwOr2tktWvcQAehTu6MeekX3MGP4ZlV7P6vSInaHNNoHs9RCtLB4ZCzSS+J/W4UueJVKkRujPfr4ZBli7Oz9Sn3hkakwRxaT3M9V+36jov/fnGcE6YZ3dRqKL3kgNyGaID11N5DTD2HocmaEdrKnDlkUZp5lAa0bAABaI0YwGL80uf6cTzWBUnY4syx6HPJ5iAln67SNLZ1nRcN41+Ginf47+7lHP8mqY6DejiDqsVGJqI8pwxXLIDOJm+LGgjKKtAoo6D9D77JzSlTcjDajnMtQds8fI7xuh20a4FL5Huz5Fw37jytahV3XKnXY1jiyj7//L3F4iin+0su29/Hl0fc/eKJeBK2IjLynkFQX9/dlWD/9kMIsogpV5DiWa6Ec2gdLL4kf9dsb7BEJuBKtpILV3DEdNnWsP3Io2/DPqrucVYrXSMNKeKhlgZ+yqZ8h8kUzYIaDSqKfW9Vefz+GMnXVRbfQx/dMmKyPUx109yH6L2JVFLFor4dVlNFk7x4qjH0Y18NnCx4BjGViUDW+1RlDy+Qymvs1GsN+WfJUcWWCJWPxIsLew3Kn3XVcVra7/npvWRu9V2Onu4DSrgGqGhGrcPMKRrUxofnuJNsF+ujlEO+vqN13IOtG7hQGMLlxLxIjOznX4XdR+/m9W/5wljL2XbNeUU7Zg7srYmEeNrWW4wGGn8f8Zgtqazv/1dxk6eK3Iz2z3vW+ua633EYc4ZszkUxpAayX2XFkEWeMuWU3vdv9uKfEsE3j3rr1EO3P7uk7p3KuvRKyJNGdf/DI7a4jWThz6t2fwU6MNLW15h6W71y4V/VtlvPvvpam0CHkPsakxgaz1PmtjUxZDrvmdmrLbJavcwgBKRP9OJZ48JHTSu59i9jPE627/W2kCr8potw1718fhrKzQ2uMfCOJ4YVp9hPCsC2LuLJOd9X4z5wPeBZO77tQ+3gBmpHQ1exJGPd9pq3/umkDWHeSR2n3PLDxzoMcApP84SPjQry70SwZwhFjYmcoEepV9rwt9IgwD9X4Oxs8AZDc3O0Pm4Z9TBCHbihbCzAC2jBIzrqE/Le22USx+PfR47lOWdTMADBO9XQ0x8gXzK99/1HDUbBMg/AwgTMOZmZ5r+LKPk/tj6bn9DEBH7C6iNX9HCGK0gRX1ECX63s0Udzu6mQEsjjxGRtMidRF75qw2WkBG/BnAkM6dSaizrP6J1hF3EoZR2UXUtr3LVY0MILgJtHYgDU+kjz51sMsBfgwgaedvuYze8AATiFgfUeu91ARKh3wYOwMobngzj4yOLjYn7of47flGCeXKM3miz22ddEk7A9gwG4j27H9deI2zsrJMG6PuzFsRfwYwLRvoHe2Ojs7sjqwTn9WnZ0J5MoDADerEM/RP6KCnismd9165Co34M4Cl2QDh2s8UV5blik1hEdt5pDsGGIBsYPuIRGc6s7wj1/tfQZjxfgaQupOMPBJgVQS4cvWPOY62Ms9S77tf1ziDhyLo06lGX+jy+fl5+3tKnlXUH6NN/VZHPdqA+gYDmNhps46j7sYo8ZTBxsr6wABSd6i/jCSjiNUKwat3ZwI5zN9wWy7MASSMZLF/+WU8xC3avdZgAFtGaRlErOUZTz/3ZldjJf4MAAeZQAYxYALKEgyACRAuz33jOawoYwBYbAKRhMxQAPNU3wwAE00gSlSYUfwjZwERy6w04CD+DAALTGCVoGUejsr47DOfuWZHtV25DACLI8LZRyDsMA6c9UasSOVC+PNhI1hCE6jplN8/27ODlj5Dto1rp4uYu64ZAJJkArWdtZcZ7Cj+GU2g57MSfgaAQ4zgToffQRjeZVHRTGDEERm73GMNBsAIbhjBieKf0QSIPkZgEnhDIyD+ZSKYaaNd69lAvRYEWN0jA0BCE5glYplvPNttR7VIHwwA/9eRR4jcCSKRbVJYnYIBoKhjtwjGjgKRZT7g1U1hRB8MADp+4zufNilM9PHxYRIYsp5iUdxhrsBkLhgAjmDEENdqE2gR7y/RJ/z4iSEgbCnkd0X23XDQahNw7DYYADAogo6+PJTIoweGgEDUFj0PEQcDACaJYuv4OcAAgMQmcOc7ez+PCVlE4fOpJSJ6Iw240emvM4W+9gt8/fvP/xtgAACA5RgCAgAGAABgAAAABgAAYAAAAAYAAGAAAAAGAABgAAAABgAAYAAAAAYAAGAAAAAGAABgAAAABgAAYAAAAAYAAGAAAAAGAABgAAAABgAAYAAAAAYAAAwAAMAAAAAMAADAAAAADAAAwAAAAAwAAMAAAAAMAADAAAAADAAAwAAAAAwAAMAAAAAMAADAAAAADAAAwAAAAAwAAMAAAAAMAADAAAAADAAAGIAiAAAGAABgAAAABgAAYAAAAAYAAGAAAAAGAABgAAAABgAAYAAAAAYAAGAAAAAGAABgAAAABgAAYAAAAAYAAGAAAAAGAABgAAAABgAAYAAAAAYAAAwAAMAAAAAMAADAAAAADAAAwAAAAAwAAMAAAAAMAADAAAAADAAAwAAAAAwAAMAAAAAMAAAwhv8AchbGPur7Y/EAAAAASUVORK5CYII=';
const $=id=>document.getElementById(id), rupiah=n=>new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',minimumFractionDigits:0}).format(Number(n)||0), esc=s=>String(s??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));
const toast=(m,ok=true)=>{const t=$('toast');t.textContent=m;t.style.background=ok?'#0f5a47':'#991b1b';t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2800)};
const api=async(action,data={})=>{const r=await fetch(WEBHOOK_URL,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,data})});const j=await r.json();if(!r.ok||j.status==='error')throw new Error(j.message||'Request gagal');return j};
function showTab(tab){document.querySelectorAll('.tab').forEach(x=>x.classList.add('hidden'));document.querySelectorAll('.navbtn').forEach(x=>x.classList.remove('nav-active'));if(tab==='deadline'){$('tab-deadline').classList.remove('hidden');$('title').textContent='Deadline Dashboard';document.querySelector('[data-tab=deadline]')?.classList.add('nav-active');loadDeadline();}else if(tab==='expense'){$('tab-expense').classList.remove('hidden');$('title').textContent='Expense';document.querySelector('[data-tab=expense]')?.classList.add('nav-active');loadExpense();}else{$('tab-ops').classList.remove('hidden');$('title').textContent='Operasional Dashboard';document.querySelector('[data-tab=ops]')?.classList.add('nav-active');showOpsView(opsView||'new');}if(window.matchMedia('(max-width:899px)').matches)closeMobileDrawer();}
function showOpsView(view){opsView=view;document.querySelectorAll('#ops-new,#ops-list').forEach(x=>x.classList.add('hidden'));$('ops-'+view).classList.remove('hidden');$('opsNavNew').classList.toggle('active',view==='new');$('opsNavList').classList.toggle('active',view==='list');if(view==='list'){renderSummary();renderOrders();}}
function toggleNav(){if(window.matchMedia('(max-width:899px)').matches)toggleMobileDrawer();else toggleSidebar()}
function toggleSidebar(){document.querySelector('.layout')?.classList.toggle('sidebar-collapsed')}
function closeMobileDrawer(){$('mobileDrawer')?.classList.remove('show');$('drawerBackdrop')?.classList.remove('show');}
function toggleMobileDrawer(){if($('mobileDrawer')?.classList.contains('show'))closeMobileDrawer();else{$('mobileDrawer')?.classList.add('show');$('drawerBackdrop')?.classList.add('show');}}
function addPackage(data={}){const row=document.createElement('div');row.className='package-row';row.innerHTML=`<div class="flex gap-2"><select class="input package flex-1">${PACKAGES.map(p=>`<option ${p===(data.PAKET||'FLEKSIBEL')?'selected':''}>${p}</option>`).join('')}</select><button type="button" onclick="this.closest('.package-row').remove();calcTotal()" class="w-10 rounded-xl bg-red-50 text-red-600"><i class="fa-solid fa-trash"></i></button></div><div class="grid grid-cols-2 gap-2 mt-2"><input class="input weight num-input" inputmode="decimal" value="${esc(data.BERAT||'')}" placeholder="Berat (kg)"><input class="input amount num-input" inputmode="decimal" value="${esc(data.TAGIHAN||'')}" placeholder="Tagihan"></div>`;$('packageRows').appendChild(row);row.querySelectorAll('input').forEach(x=>x.addEventListener('input',calcTotal));}
function calcTotal(){let t=0;document.querySelectorAll('#packageRows .amount').forEach(x=>t+=Number(String(x.value).replace(/[^0-9.-]/g,''))||0);$('orderTotal').textContent=rupiah(t)}
function draftOrder(e){e.preventDefault();const rows=[...document.querySelectorAll('#packageRows .package-row')];if(!rows.length){toast('Tambahkan minimal satu paket',false);return}draft={NAMA:$('f-nama').value.trim(),NO_WA:$('f-wa').value.trim(),METODE_TRANSAKSI:$('f-payment').value,items:rows.map(r=>({PAKET:r.querySelector('.package').value,BERAT:r.querySelector('.weight').value,TAGIHAN:r.querySelector('.amount').value}))};try{previewMode='create';previewOrder={...draft,ORDER_ID:'PREVIEW'};$('receiptPreview').innerHTML=receiptHTML(previewOrder);setPreviewButtons('create');$('previewTitle').textContent='Preview Struk';$('previewSubtitle').textContent='Periksa sebelum menyimpan';$('previewModal').classList.add('show');document.body.classList.add('overflow-hidden')}catch(err){toast('Preview gagal: '+err.message,false)}}
function receiptHTML(o){
  const items=Array.isArray(o.items)?o.items:[];
  const total=items.reduce((s,x)=>s+(Number(String(x.TAGIHAN||'').replace(/[^0-9.-]/g,''))||0),0);
  const dt=o.START?new Date(String(o.START).replace(' ','T')):new Date();
  const date=isNaN(dt.getTime())?new Date().toLocaleString('id-ID',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}):dt.toLocaleString('id-ID',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
  const paymentStatus=String(o.STATUS_PEMBAYARAN||'BELUM LUNAS').toUpperCase();
  const notes=[
    'Baju putih dicuci terpisah minimal 3 kg.',
    'Kami tidak menerima komplain lebih dari 2x24jam setelah customer menerima Laundry.',
    'Baju yang mudah luntur TAPI tidak memberitahu kami sebelumnya, bukan tanggung jawab kami.',
    'Di sarankan baju luntur untuk cuci satuan.',
    'Jika ingin pakaian Bapak/Ibu dikerjakan lebih optimal disarankan untuk pengerjaan satuan.',
    'Laundry yang lebih dari 10 hari tidak diambil bukan menjadi tanggung jawab kami.',
    'Laundry anda GRATIS apabila tidak mendapatkan nota.'
  ];
  return `<div class="receipt">
    <div style="text-align:center"><img src="${FORTUNA_LOGO_PNG}" alt="Fortuna Laundry"><div class="receipt-brand">FORTUNA LAUNDRY</div><div class="receipt-sub">Jalan Raya Inpres no 4</div><div class="receipt-sub">Jakarta Timur</div><div class="receipt-sub">085693280500</div></div>
    <div class="row" style="margin-top:6px"><span>${esc(date)}</span><b>#${esc(o.ORDER_ID||'PREVIEW')}</b></div>
    <div style="font-weight:800;margin-top:2px">${esc(o.NAMA||'-')}</div>
    <hr>
    ${items.map((x,i)=>`<div class="item"><div class="item-name">${i+1}. ${esc(x.PAKET||'-')}</div><div class="item-meta"><span>${esc(x.BERAT||'0')}Kg</span><span>${rupiah(x.TAGIHAN)}</span></div></div>`).join('')}
    <hr>
    <div class="row total"><span>Total</span><span>${rupiah(total)}</span></div>
    <div style="text-align:right;font-size:10px">${esc(paymentStatus)}${o.METODE_TRANSAKSI&&o.METODE_TRANSAKSI!=='BELUM LUNAS'?` • ${esc(o.METODE_TRANSAKSI)}`:''}</div>
    <div style="text-align:center;margin-top:5px;font-size:10px">-- PEMBAYARAN HARAP MENGGUNAKAN QRIS --</div>
    <div class="note-title">PERHATIAN</div>
    <div class="notes">${notes.map(n=>`- ${esc(n)}`).join('<br><br>')}</div>
    <div class="footer">Kritik dan saran<br>085693280500<br><br>#Terimakasih Kasih#</div>
  </div>`
}
function setPreviewButtons(mode){
  const create=mode==='create';
  $('previewCreatePrint').classList.toggle('hidden',!create);
  $('previewCreatePrintWa').classList.toggle('hidden',!create);
  $('previewCreateSave').classList.toggle('hidden',!create);
  $('previewReprint').classList.toggle('hidden',create);
}
function openPrintPreview(o){
  previewMode='reprint'; previewOrder=o;
  $('receiptPreview').innerHTML=receiptHTML(o);
  $('previewTitle').textContent='Preview Struk';
  $('previewSubtitle').textContent='Order #'+o.ORDER_ID+' • siap untuk dicetak';
  setPreviewButtons('reprint');
  $('previewModal').classList.add('show');
  document.body.classList.add('overflow-hidden');
}
async function confirmReprint(){
  if(!previewOrder||busy)return;
  try{busy=true;await printReceipt(previewOrder);closeModal('previewModal');toast('Struk #'+previewOrder.ORDER_ID+' dikirim ke printer')}catch(e){toast('Printer: '+e.message,false)}finally{busy=false}
}
async function confirmCreate(print,sendWa){if(busy||!draft)return;busy=true;try{const res=await api('order_create',draft);const o=res.data;closeModal('previewModal');$('f-nama').value='';$('f-wa').value='';$('f-payment').value='BELUM LUNAS';$('packageRows').innerHTML='';addPackage();calcTotal();await loadDashboard(true);const full={...draft,...o};if(print){try{await printReceipt(full)}catch(err){toast('Printer gagal: '+err.message,false)}}if(sendWa){const n=normalizeWaNumber(full.NO_WA);const link=buildStatusLink(full);if(n){const items=Array.isArray(full.items)?full.items:[];const itemText=items.map(x=>`- ${x.PAKET||'-'} — ${x.BERAT||0}Kg`).join('\n');const msg=`Halo ${full.NAMA||'Customer'},\n\nTerima kasih sudah menggunakan Fortuna Laundry.\n\nPesanan #${full.ORDER_ID} sudah kami terima.\n${itemText}\n\nTotal: ${rupiah(items.reduce((sum,x)=>sum+(Number(x.TAGIHAN)||0),0))}\n\nCek status cucian:\n${link||'Link status akan tersedia di customer dashboard.'}\n\nTerima kasih.\nFortuna Laundry`;window.open('https://wa.me/'+n+'?text='+encodeURIComponent(msg),'_blank')}else toast('Order tersimpan, tetapi nomor WhatsApp customer kosong.',false)}toast('Order #'+o.ORDER_ID+' berhasil disimpan');}catch(e){toast(e.message,false)}finally{busy=false}}
function openWA(o){waTarget=o;$('waOrderInfo').textContent='Order #'+o.ORDER_ID+' • '+(o.NAMA||'-');const link=buildStatusLink(o);$('waStatusLink').textContent=link||'Link status belum dikonfigurasi';$('waModal').classList.add('show');document.body.classList.add('overflow-hidden')}
function normalize(o){return o}
function renderOrders(){
  const q=($('search')?.value||'').toLowerCase();
  const list=orders.filter(o=>{
    const items=o.items||[];
    const matchesStatus=statusFilter==='ALL'||items.some(i=>String(i.STATUS||'').toUpperCase()===statusFilter);
    const matchesSearch=(o.ORDER_ID+' '+o.NAMA+' '+o.PAKET+' '+items.map(i=>i.PAKET).join(' ')).toLowerCase().includes(q);
    return matchesStatus&&matchesSearch;
  });
  $('orderCount').textContent=list.length+' order'+(statusFilter!=='ALL'?' • filter '+statusFilter:'');
  $('orderRows').innerHTML=list.map(o=>{
    const unpaid=o.STATUS_PEMBAYARAN==='BELUM LUNAS';
    const allDone=(o.items||[]).length>0&&(o.items||[]).every(i=>i.STATUS==='SELESAI');
    const itemHtml=(o.items||[]).map(i=>`
      <div class="order-item">
        <div class="order-item-head">
          <div class="order-item-name">${esc(i.PAKET)}</div>
          <span class="pill s-${esc(i.STATUS)}">${esc(i.STATUS)}</span>
        </div>
        <div class="order-item-meta"><span>${esc(i.BERAT)} kg</span><span>•</span><span>${rupiah(i.TAGIHAN)}</span></div>
      </div>`).join('');
    const itemActions=(o.items||[]).filter(i=>i.STATUS!=='SELESAI').map(i=>`
      <div class="order-action-item">
        <span class="text-[8px] font-black text-slate-400 self-center mr-1">${esc(i.ITEM_ID)}</span>
        <button onclick="editItem('${esc(i.ITEM_ID)}')" title="Edit ${esc(i.ITEM_ID)}" class="btn text-slate-500 bg-slate-100 rounded-lg px-2 py-1 text-[10px]"><i class="fa-solid fa-pen"></i></button>
        ${i.STATUS==='DITERIMA'?`<button onclick="setStatus('${esc(i.ITEM_ID)}','DIPROSES')" class="btn text-[9px] bg-orange-50 text-orange-700 rounded-lg px-2 py-1">PROSES</button>`:''}
        ${i.STATUS==='DIPROSES'?`<button onclick="setStatus('${esc(i.ITEM_ID)}','QC')" class="btn text-[9px] bg-blue-50 text-blue-700 rounded-lg px-2 py-1">QC</button>`:''}
        ${i.STATUS==='QC'||i.STATUS==='DIPROSES'?`<button onclick="setStatus('${esc(i.ITEM_ID)}','SIAP')" class="btn text-[9px] bg-emerald-50 text-emerald-700 rounded-lg px-2 py-1">SIAP</button>`:''}
        ${i.STATUS==='SIAP'?`<button onclick="setStatus('${esc(i.ITEM_ID)}','SELESAI')" class="btn text-[9px] bg-slate-900 text-white rounded-lg px-2 py-1">SELESAI</button>`:''}
      </div>`).join('');
    return `<tr class="border-t border-slate-100 align-top">
      <td class="px-3 py-2.5 font-black whitespace-nowrap">#${esc(o.ORDER_ID)}<div class="text-[9px] text-slate-400 mt-0.5">${o.START?new Date(o.START.replace(' ','T')).toLocaleString('id-ID',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):''}</div></td>
      <td class="px-3 py-2.5 min-w-[130px]"><b class="text-xs">${esc(o.NAMA)}</b><div class="text-[9px] text-slate-400">${esc(o.NO_WA)}</div>${unpaid?'<span class="pill unpaid inline-block mt-1">BELUM LUNAS</span>':''}</td>
      <td class="px-3 py-2.5 min-w-[270px]"><div class="order-package-list">${itemHtml}</div></td>
      <td class="px-3 py-2.5 whitespace-nowrap"><div class="order-total"><span class="order-total-label">Total</span><span class="order-total-value">${rupiah(o.TOTAL_TAGIHAN)}</span></div></td>
      <td class="px-3 py-2.5 min-w-[185px]"><div class="order-actions">
        <div class="order-action-top">
          ${unpaid&&!allDone?`<button onclick="openPay('${esc(o.ORDER_ID)}')" class="btn text-[10px] font-black bg-red-50 text-red-700 rounded-lg px-2.5 py-1.5"><i class="fa-solid fa-check mr-1"></i>LUNAS</button>`:''}
          <button onclick="printOrder('${esc(o.ORDER_ID)}')" title="Print" class="btn text-slate-600 bg-slate-100 rounded-lg px-2.5 py-1.5"><i class="fa-solid fa-print"></i></button>
          <button onclick="waOrder('${esc(o.ORDER_ID)}')" title="WhatsApp" class="btn text-emerald-700 bg-emerald-50 rounded-lg px-2.5 py-1.5"><i class="fa-brands fa-whatsapp"></i></button>
        </div>
        ${!allDone&&itemActions?`<div class="order-action-status">${itemActions}</div>`:''}
      </div></td>
    </tr>`;
  }).join('')||`<tr><td colspan="5" class="p-10 text-center text-slate-400">Belum ada order.</td></tr>`;
}
function toggleStatusFilter(filter,force=false){if(!force&&statusFilter===filter&&filter!=='ALL')statusFilter='ALL';else statusFilter=filter;document.querySelectorAll('.summary-filter').forEach(b=>b.classList.toggle('active',b.dataset.filter===statusFilter));renderOrders()}
function renderSummary(){for(const k of ['total','diterima','diproses','qc','siap','selesai'])$('sum-'+k).textContent=summary[k]||0}
let summary={};
async function loadDashboard(silent=false){try{const j=await api('read');orders=j.data?.orders||[];summary=j.data?.summary||{};renderSummary();renderOrders();if(!silent)toast('Data berhasil diperbarui')}catch(e){toast('Gagal memuat dashboard: '+e.message,false)}}
function findItem(id){for(const o of orders){const i=(o.items||[]).find(x=>x.ITEM_ID===id);if(i)return{o,i}}return null}
async function setStatus(item,status){if(!confirm('Ubah item menjadi '+status+'?'))return;try{await api('update_status',{ITEM_ID:item,STATUS:status});await loadDashboard(true);if(status==='SIAP')loadDeadline();toast('Status berhasil diperbarui')}catch(e){toast(e.message,false)}}
async function markReady(item){if(!confirm('Tandai item sebagai SIAP?'))return;try{await api('ready_item',{ITEM_ID:item,STATUS:'SIAP'});await loadDashboard(true);await loadDeadline();toast('Item ditandai SIAP')}catch(e){toast(e.message,false)}}
function editItem(id){const f=findItem(id);if(!f||f.o.STATUS==='SELESAI')return;const o=f.o,i=f.i;$('edit-item').value=id;$('edit-id').textContent='#'+o.ORDER_ID+' • '+id;$('edit-nama').value=o.NAMA;$('edit-wa').value=o.NO_WA;$('edit-paket').innerHTML=PACKAGES.map(p=>`<option ${p===i.PAKET?'selected':''}>${p}</option>`).join('');$('edit-berat').value=i.BERAT||'';$('edit-tagihan').value=i.TAGIHAN||'';$('editModal').classList.add('show')}
async function saveEdit(e){e.preventDefault();try{await api('order_edit',{ITEM_ID:$('edit-item').value,NAMA:$('edit-nama').value,NO_WA:$('edit-wa').value,PAKET:$('edit-paket').value,BERAT:$('edit-berat').value,TAGIHAN:$('edit-tagihan').value});closeModal('editModal');await loadDashboard(true);toast('Item diperbarui')}catch(e){toast(e.message,false)}}
function openPay(id){payOrder=id;$('payModal').classList.add('show')}
async function pay(method){try{await api('payment_update',{ORDER_ID:payOrder,METODE_TRANSAKSI:method});closeModal('payModal');await loadDashboard(true);toast('Pembayaran #'+payOrder+' menjadi LUNAS')}catch(e){toast(e.message,false)}}
function waOrder(id){const o=orders.find(x=>x.ORDER_ID===id);if(!o)return;waTarget=o;$('waOrderInfo').textContent='Order #'+o.ORDER_ID+' • '+(o.NAMA||'-');const link=buildStatusLink(o);$('waStatusLink').textContent=link||'Link status belum dikonfigurasi';$('waModal').classList.add('show');document.body.classList.add('overflow-hidden')}
function buildStatusLink(o){if(!STATUS_CHECK_BASE_URL)return '';const sep=STATUS_CHECK_BASE_URL.includes('?')?'&':'?';return STATUS_CHECK_BASE_URL+sep+'order='+encodeURIComponent(o.ORDER_ID)}
function normalizeWaNumber(v){let n=String(v||'').replace(/\D/g,'');if(n.startsWith('0'))n='62'+n.slice(1);return n}
function sendWAOption(type){const o=waTarget;if(!o)return;const n=normalizeWaNumber(o.NO_WA);if(!n){toast('Nomor WhatsApp kosong',false);return}const link=buildStatusLink(o);if((type==='ready'||type==='status')&&!link){toast('Link status belum dikonfigurasi di frontend',false);return}let msg='';if(type==='ready'){msg=`Halo ${o.NAMA},\n\nLaundry dengan nomor order #${o.ORDER_ID} sudah selesai dan siap diambil.\n\nCek status cucian: ${link}\n\nTerima kasih — Fortuna Laundry.`}else if(type==='status'){msg=`Halo ${o.NAMA},\n\nCek status cucian untuk order #${o.ORDER_ID}:\n${link}\n\nTerima kasih — Fortuna Laundry.`}closeModal('waModal');if(type==='chat')window.open('https://wa.me/'+n,'_blank');else window.open('https://wa.me/'+n+'?text='+encodeURIComponent(msg),'_blank')}
async function printOrder(id){const o=orders.find(x=>x.ORDER_ID===id);if(!o)return;openPrintPreview(o)}
function deadlineBucketClass(bucket){return bucket==='OVERDUE'?'deadline-overdue':bucket==='DEADLINE'?'deadline-critical':'deadline-priority'}
function deadlineBucketLabel(bucket){return bucket==='OVERDUE'?'TERLAMBAT':bucket==='DEADLINE'?'MENDEKATI DEADLINE':'PRIORITAS'}
function deadlineStatusClass(status){return 's-'+String(status||'').toUpperCase().replace(/[^A-Z0-9_-]/g,'')}
function deadlineSearchText(x){return [x.ORDER_ID,x.ITEM_ID,x.NAMA,x.PAKET,x.BERAT,x.STATUS,x.BUCKET].join(' ').toLowerCase()}
function deadlineNaturalText(readyAt){
  if(!readyAt)return 'Waktu READY belum ditentukan';
  const d=new Date(readyAt);
  if(Number.isNaN(d.getTime()))return 'Waktu READY belum ditentukan';
  const day=d.toLocaleDateString('id-ID',{weekday:'long'});
  const hour=d.getHours();
  const minute=String(d.getMinutes()).padStart(2,'0');
  let h=hour%12||12;
  const period=hour<11?'pagi':hour<15?'siang':hour<18?'sore':'malam';
  const time=`${h}:${minute}`;
  return `Harus sudah siap sebelum jam ${time} ${period} hari ${day}`;
}
function renderDeadline(){
  const q=String($('deadlineSearch')?.value||'').trim().toLowerCase();
  const list=deadlineItems.filter(x=>(deadlineFilter==='ALL'||x.BUCKET===deadlineFilter)&&(!q||deadlineSearchText(x).includes(q)));
  $('deadlineCount').textContent=list.length+' item'+(list.length===1?'':'s')+(deadlineFilter!=='ALL'?' • filter '+deadlineBucketLabel(deadlineFilter):'');
  $('deadlineList').innerHTML=list.length?list.map(x=>{
    const remain=Math.max(0,Math.min(100,Number(x.REMAINING_PERCENT)||0));
    const progress=Math.max(0,Math.min(100,100-remain));
    const bucket=x.BUCKET||'PRIORITY';
    const cls=deadlineBucketClass(bucket);
    const bar=bucket==='OVERDUE'?'bg-red-800':bucket==='DEADLINE'?'bg-red-500':'bg-amber-500';
    const target=x.READY_AT?new Date(x.READY_AT):null;
    const targetText=target&&!isNaN(target.getTime())?target.toLocaleString('id-ID',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):'-';
    const readyBtn=x.STATUS==='SIAP'||x.STATUS==='SELESAI'?'':`<button onclick="markReady('${esc(x.ITEM_ID)}')" class="btn bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-lg px-2.5 py-1.5 text-[10px] font-black whitespace-nowrap"><i class="fa-solid fa-check mr-1"></i>SIAP</button>`;
    return `<div class="deadline-row ${cls}">
      <div class="deadline-main">
        <div class="deadline-id"><b>#${esc(x.ORDER_ID)}</b><span>${esc(x.ITEM_ID)}</span></div>
        <div class="deadline-customer"><b>${esc(x.NAMA||'-')}</b><span>${esc(x.PAKET||'-')}</span></div>
        <div class="deadline-meta"><span>${esc(x.BERAT||'0')} kg</span><span>•</span><span>READY ${targetText}</span><span>•</span><span class="pill ${deadlineStatusClass(x.STATUS)}">${esc(x.STATUS||'-')}</span></div>
        <div class="deadline-natural">${esc(deadlineNaturalText(x.READY_AT))}</div>
      </div>
      <div class="deadline-progress">
        <div class="flex justify-between items-center text-[10px] font-bold mb-1"><span>${deadlineBucketLabel(bucket)}</span><span>${remain}% tersisa</span></div>
        <div class="h-1.5 bg-slate-100 rounded-full overflow-hidden"><div class="h-full ${bar} rounded-full transition-all duration-300" style="width:${progress}%"></div></div>
      </div>
      <div class="deadline-action">${readyBtn}</div>
    </div>`;
  }).join(''):`<div class="p-10 text-center text-slate-400 text-sm">Tidak ada item yang cocok dengan filter.</div>`;
  document.querySelectorAll('[data-dl-filter]').forEach(b=>b.classList.toggle('active',b.dataset.dlFilter===deadlineFilter));
}
function toggleDeadlineFilter(filter,force=false){if(!force&&deadlineFilter===filter&&filter!=='ALL')deadlineFilter='ALL';else deadlineFilter=filter;renderDeadline()}
async function loadDeadline(){
  const btn=$('deadlineRefreshBtn'),icon=$('deadlineRefreshIcon');
  if(btn)btn.disabled=true;if(icon)icon.className='fa-solid fa-spinner fa-spin mr-1';
  try{
    const j=await api('deadline');const d=j.data||{};deadlineItems=Array.isArray(d.items)?d.items:[];
    const deadlineTotal=d.summary?.total??deadlineItems.length;$('dl-total').textContent=deadlineTotal;$('dl-priority').textContent=d.summary?.priority||0;$('dl-deadline').textContent=d.summary?.deadline||0;$('dl-overdue').textContent=d.summary?.overdue||0;if($('globalDeadlineCount'))$('globalDeadlineCount').textContent=deadlineTotal;
    renderDeadline();toast('Deadline berhasil diperbarui');
  }catch(e){toast('Deadline gagal dimuat: '+e.message,false)}
  finally{if(btn)btn.disabled=false;if(icon)icon.className='fa-solid fa-rotate-right mr-1'}
}
function expenseDateLabel(v){if(!v)return '-';const d=new Date(String(v).length<=10?String(v)+'T00:00:00':String(v));return Number.isNaN(d.getTime())?String(v):d.toLocaleDateString('id-ID',{day:'2-digit',month:'short',year:'numeric'});}
function expenseCategoryClass(k){const v=String(k||'').toUpperCase();if(v.includes('LISTRIK')||v.includes('AIR')||v.includes('INTERNET'))return 'bg-blue-50 text-blue-700';if(v.includes('BAHAN')||v.includes('SUPPLY'))return 'bg-amber-50 text-amber-700';if(v.includes('GAJI')||v.includes('UPAH'))return 'bg-violet-50 text-violet-700';return 'bg-slate-100 text-slate-600'}
let expenses=[];
function renderExpense(){const q=String($('expenseSearch')?.value||'').trim().toLowerCase();const cat=$('expenseCategoryFilter')?.value||'ALL';const method=$('expenseMethodFilter')?.value||'ALL';const filtered=expenses.filter(x=>{const hay=String(x.KATEGORI||'')+' '+String(x.KETERANGAN||'')+' '+String(x.EXPENSE_ID||'');return(!q||hay.toLowerCase().includes(q))&&(cat==='ALL'||String(x.KATEGORI||'LAINNYA')===cat)&&(method==='ALL'||String(x.METODE_TRANSAKSI||'')===method)});$('expenseListCount').textContent=filtered.length+' expense ditampilkan';$('expenseList').innerHTML=filtered.length?filtered.map(x=>`<div class="expense-row px-4 py-3.5"><div class="flex items-start justify-between gap-4"><div class="min-w-0"><div class="flex items-center gap-2 flex-wrap"><span class="expense-cat ${expenseCategoryClass(x.KATEGORI)}">${esc(x.KATEGORI||'LAINNYA')}</span><span class="text-[10px] text-slate-400">${esc(x.EXPENSE_ID||'')}</span></div><div class="font-bold text-sm mt-1.5 break-words">${esc(x.KETERANGAN||'-')}</div><div class="text-[11px] text-slate-500 mt-1">${expenseDateLabel(x.TANGGAL)}</div></div><div class="text-right shrink-0"><div class="font-black text-sm">${rupiah(x.NOMINAL)}</div><div class="pill mt-1 inline-block bg-slate-50 text-slate-500 border border-slate-200">${esc(x.METODE_TRANSAKSI||'-')}</div></div></div></div>`).join(''):`<div class="p-10 text-center text-slate-400 text-sm">Tidak ada expense yang cocok dengan filter.</div>`;}
function populateExpenseCategories(){const el=$('expenseCategoryFilter');if(!el)return;const current=el.value;const cats=[...new Set(expenses.map(x=>String(x.KATEGORI||'LAINNYA').trim()||'LAINNYA'))].sort((a,b)=>a.localeCompare(b,'id'));el.innerHTML='<option value="ALL">Semua kategori</option>'+cats.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');el.value=cats.includes(current)?current:'ALL';}
function updateExpenseSummary(){const now=new Date();const today=now.toISOString().slice(0,10);const ym=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0');const amount=x=>Number(String(x.NOMINAL||'').replace(/[^0-9.-]/g,''))||0;const day=expenses.filter(x=>String(x.TANGGAL||'').slice(0,10)===today).reduce((s,x)=>s+amount(x),0);const month=expenses.filter(x=>String(x.TANGGAL||'').slice(0,7)===ym).reduce((s,x)=>s+amount(x),0);$('expenseTotal').textContent=rupiah(day);$('expenseMonthTotal').textContent=rupiah(month);if($('expenseTodayLabel'))$('expenseTodayLabel').textContent=now.toLocaleDateString('id-ID',{weekday:'long',day:'2-digit',month:'long',year:'numeric'});$('expenseMonthLabel').textContent=now.toLocaleDateString('id-ID',{month:'long',year:'numeric'});}
async function loadExpense(){const btn=$('expenseRefreshBtn'),icon=$('expenseRefreshIcon');if(btn)btn.disabled=true;if(icon)icon.className='fa-solid fa-spinner fa-spin mr-1';try{const j=await api('expense_read');const d=j.data||{};expenses=Array.isArray(d.expenses)?d.expenses:[];updateExpenseSummary();populateExpenseCategories();renderExpense();toast('Expense berhasil diperbarui');}catch(e){toast('Expense gagal dimuat: '+e.message,false)}finally{if(btn)btn.disabled=false;if(icon)icon.className='fa-solid fa-rotate-right mr-1';}}
async function createExpense(e){e.preventDefault();const btn=$('expenseSaveBtn'),icon=$('expenseSaveIcon'),txt=$('expenseSaveText');if(btn?.disabled)return;btn.disabled=true;if(icon)icon.className='fa-solid fa-spinner fa-spin mr-1';if(txt)txt.textContent='Menyimpan...';try{await api('expense_create',{TANGGAL:$('e-tanggal').value,KATEGORI:$('e-kategori').value,KETERANGAN:$('e-keterangan').value,NOMINAL:$('e-nominal').value,METODE_TRANSAKSI:$('e-metode').value});e.target.reset();$('e-tanggal').value=new Date().toISOString().slice(0,10);await loadExpense();toast('Expense berhasil disimpan');}catch(err){toast('Expense gagal disimpan: '+err.message,false)}finally{btn.disabled=false;if(icon)icon.className='fa-solid fa-floppy-disk mr-1';if(txt)txt.textContent='Simpan Expense';}}
function refreshActiveTab(){const btn=$('globalRefreshBtn'),icon=$('globalRefreshIcon');if(btn)btn.disabled=true;if(icon)icon.className='fa-solid fa-spinner fa-spin mr-1';const active=document.querySelector('.tab:not(.hidden)')?.id;const done=active==='tab-deadline'?loadDeadline():active==='tab-expense'?loadExpense():loadDashboard();Promise.resolve(done).finally(()=>{if(btn)btn.disabled=false;if(icon)icon.className='fa-solid fa-rotate-right mr-1'});}
function closeModal(id){$(id).classList.remove('show');if(id==='previewModal'||id==='numpadModal'||id==='payModal')document.body.classList.remove('overflow-hidden')}
// Web Bluetooth / ESC-POS: reuse authorized device first, ask pairing only if needed.
// BLUETOOTH THERMAL PRINTER — based on the older Fortuna cashier implementation.
// Reuse authorized devices first; if none is usable, open the browser Bluetooth chooser.
let printerCharacteristic=null;
let printerConnecting=false;
const PRINTER_OPTIONAL_SERVICES=[
  '000018f0-0000-1000-8000-00805f9b34fb',
  '0000ff00-0000-1000-8000-00805f9b34fb',
  '0000ffe0-0000-1000-8000-00805f9b34fb',
  '0000ffe5-0000-1000-8000-00805f9b34fb',
  '0000e025-0000-1000-8000-00805f9b34fb',
  '00001101-0000-1000-8000-00805f9b34fb',
  '49535343-fe7d-4ae5-8fa9-9fafd205e455'
];
function setPrinterUI(connected,text){
  const btn=$('printerBtn'),icon=$('printerIcon'),label=$('printerText');
  if(!btn)return;
  label.textContent=text||(connected?'Terhubung':'Hubungkan ke printer');
  icon.className=connected?'fa-solid fa-print mr-1 text-emerald-600':'fa-solid fa-print mr-1 text-red-600';
  btn.classList.toggle('bg-emerald-50',connected);
  btn.classList.toggle('text-[#0F5A47]',connected);
}
async function findWritableCharacteristic(device){
  if(!device?.gatt)return null;
  const server=device.gatt.connected?device.gatt.server:await device.gatt.connect();
  const services=await server.getPrimaryServices();
  for(const service of services){
    const chars=await service.getCharacteristics();
    for(const c of chars)if(c.properties.writeWithoutResponse||c.properties.write)return c;
  }
  return null;
}
function onPrinterDisconnected(){
  printerCharacteristic=null;
  setPrinterUI(false,'Hubungkan ke printer');
  toast('Thermal printer terputus. Hubungkan kembali sebelum mencetak.',false);
}
function bindPrinterDisconnect(device){
  if(!device)return;
  device.removeEventListener('gattserverdisconnected',onPrinterDisconnected);
  device.addEventListener('gattserverdisconnected',onPrinterDisconnected);
}
async function restorePrinter(){
  if(!navigator.bluetooth?.getDevices)return false;
  try{
    const devices=await navigator.bluetooth.getDevices();
    if(!devices.length)return false;
    const ordered=[...devices.filter(d=>d.name&&(/RPP02N|RPP|Printer|Thermal|POS|MTP/i.test(d.name))),...devices.filter(d=>!d.name||!(/RPP02N|RPP|Printer|Thermal|POS|MTP/i.test(d.name)))];
    for(const device of ordered){
      try{
        printer=device;bindPrinterDisconnect(printer);
        printerCharacteristic=await findWritableCharacteristic(printer);
        if(printerCharacteristic){setPrinterUI(true,'Terhubung');return true;}
      }catch(_){printerCharacteristic=null;}
    }
  }catch(err){console.debug('Printer belum dapat dipulihkan:',err)}
  printerCharacteristic=null;return false;
}
async function choosePrinter(){
  return await navigator.bluetooth.requestDevice({acceptAllDevices:true,optionalServices:PRINTER_OPTIONAL_SERVICES});
}
async function connectPrinter(){
  if(printerConnecting)return !!printerCharacteristic;
  if(!navigator.bluetooth){toast('Browser tidak mendukung Web Bluetooth. Gunakan Chrome/Edge desktop.',false);return false}
  const btn=$('printerBtn'),icon=$('printerIcon'),txt=$('printerText');
  printerConnecting=true;if(btn)btn.disabled=true;if(icon)icon.className='fa-solid fa-spinner fa-spin mr-1';if(txt)txt.textContent='Mencari printer...';
  try{
    // A. Coba device yang sedang tersimpan/terhubung.
    if(printer?.gatt){try{bindPrinterDisconnect(printer);printerCharacteristic=await findWritableCharacteristic(printer);if(printerCharacteristic){setPrinterUI(true,'Terhubung');toast('Printer terhubung');return true}}catch(_){printerCharacteristic=null}}
    // B. Coba semua device yang sudah diberi permission browser.
    if(navigator.bluetooth.getDevices){
      try{
        const devices=await navigator.bluetooth.getDevices();
        const ordered=[...devices.filter(d=>d.name&&(/RPP02N|RPP|Printer|Thermal|POS|MTP/i.test(d.name))),...devices.filter(d=>!d.name||!(/RPP02N|RPP|Printer|Thermal|POS|MTP/i.test(d.name)))];
        for(const device of ordered){
          try{printer=device;bindPrinterDisconnect(printer);printerCharacteristic=await findWritableCharacteristic(printer);if(printerCharacteristic){setPrinterUI(true,'Terhubung');toast('Printer terhubung');return true}}catch(_){printerCharacteristic=null}
        }
      }catch(_){/* lanjut chooser */}
    }
    // C. Tidak ada device yang bisa dipakai → browser menampilkan daftar Bluetooth yang tersedia.
    printer=await choosePrinter();bindPrinterDisconnect(printer);
    printerCharacteristic=await findWritableCharacteristic(printer);
    if(!printerCharacteristic)throw new Error('Printer ditemukan, tetapi characteristic Bluetooth untuk mengirim data tidak ditemukan');
    setPrinterUI(true,'Terhubung');toast('Printer '+(printer.name||'Bluetooth')+' terhubung');return true;
  }catch(e){
    printerCharacteristic=null;setPrinterUI(false,'Hubungkan ke printer');
    toast(e?.name==='NotFoundError'?'Pemilihan printer dibatalkan.':(e?.message||'Gagal menghubungkan printer.'),false);return false;
  }finally{printerConnecting=false;if(btn)btn.disabled=false}
}
async function ensurePrinter(){
  if(printerCharacteristic&&printer?.gatt?.connected)return true;
  if(printer){try{bindPrinterDisconnect(printer);printerCharacteristic=await findWritableCharacteristic(printer);if(printerCharacteristic){setPrinterUI(true,'Terhubung');return true}}catch(_){printerCharacteristic=null}}
  return false;
}
async function logoToEscPos(){const img=new Image();img.src=FORTUNA_LOGO_PNG;await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject});const maxWidth=320;const ratio=Math.min(1,maxWidth/img.naturalWidth);const w=Math.max(8,Math.round(img.naturalWidth*ratio));const h=Math.max(8,Math.round(img.naturalHeight*ratio));const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);ctx.drawImage(img,0,0,w,h);const data=ctx.getImageData(0,0,w,h).data;const rowBytes=Math.ceil(w/8);const bitmap=new Uint8Array(8+rowBytes*h);bitmap[0]=0x1d;bitmap[1]=0x76;bitmap[2]=0x30;bitmap[3]=0x00;bitmap[4]=rowBytes&0xff;bitmap[5]=(rowBytes>>8)&0xff;bitmap[6]=h&0xff;bitmap[7]=(h>>8)&0xff;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;const gray=data[i]*.299+data[i+1]*.587+data[i+2]*.114;if(gray<180)bitmap[8+y*rowBytes+(x>>3)]|=0x80>>(x&7)}const out=new Uint8Array(5+bitmap.length+3);out.set([0x1b,0x40,0x1b,0x61,0x01],0);out.set(bitmap,5);out.set([0x1b,0x61,0x00,0x1b,0x45,0x00],5+bitmap.length);return out}
function receiptTextLine(left,right,width=32){left=String(left??'');right=String(right??'');const gap=Math.max(1,width-left.length-right.length);return left+' '.repeat(gap)+right+'\n'}
function wrapReceipt(text,width=32){const words=String(text??'').split(/\s+/);const out=[];let line='';for(const word of words){if((line?line.length+1:0)+word.length<=width)line+=(line?' ':'')+word;else{if(line)out.push(line);line=word.slice(0,width)}}if(line)out.push(line);return out}
async function printReceipt(o){
  // SETIAP aksi cetak wajib memastikan printer benar-benar tersambung.
  // Jika koneksi hilang/tidak ada, minta operator menghubungkan thermal printer lagi.
  let ready=await ensurePrinter();
  if(!ready){
    ready=await connectPrinter();
    if(!ready) throw new Error('Thermal printer belum terhubung. Hubungkan printer lalu coba cetak lagi.');
  }
  const enc=new TextEncoder();
  const bytes=[];
  const push=s=>bytes.push(...enc.encode(s));
  const nl='\n';
  try{ bytes.push(...await logoToEscPos()); }
  catch(e){ push('\x1B\x40\x1B\x61\x01'); }

  const dt=new Date(o.START ? String(o.START).replace(' ','T') : Date.now());
  const date=isNaN(dt.getTime()) ? new Date().toLocaleString('id-ID') : dt.toLocaleString('id-ID',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
  const items=Array.isArray(o.items)?o.items:[];
  const total=items.reduce((s,x)=>s+(Number(x.TAGIHAN)||0),0);

  push('FORTUNA LAUNDRY'+nl);
  push('Jalan Raya Inpres no 4'+nl);
  push('Jakarta Timur'+nl);
  push('085693280500'+nl+nl);
  push(receiptTextLine(date,'#'+o.ORDER_ID));
  push('\x1B\x45\x01'+String(o.NAMA||'-').toUpperCase()+'\x1B\x45\x00'+nl);
  push('--------------------------------'+nl);

  items.forEach((x,i)=>{
    const lines=wrapReceipt((i+1)+'. '+String(x.PAKET||'-').toUpperCase(),32);
    push('\x1B\x45\x01'+lines[0]+'\x1B\x45\x00'+nl);
    for(let j=1;j<lines.length;j++)push('  '+lines[j]+nl);
    push(receiptTextLine(String(x.BERAT||0)+'Kg',rupiah(x.TAGIHAN)));
  });

  push('--------------------------------'+nl);
  push(receiptTextLine('TOTAL',rupiah(total)));
  const paymentStatus=String(o.STATUS_PEMBAYARAN||'BELUM LUNAS').toUpperCase();
  const paymentMethod=String(o.METODE_TRANSAKSI||'BELUM LUNAS').toUpperCase();
  push('\x1B\x61\x01\x1B\x45\x01'+(paymentStatus==='LUNAS'?'LUNAS':'BELUM DIBAYAR')+'\x1B\x45\x00'+nl);
  push('Metode: '+paymentMethod+nl);
  push('\x1B\x61\x00');
  push('\n-- PEMBAYARAN HARAP MENGGUNAKAN QRIS --\n\n');
  push('\x1B\x45\x01PERHATIAN\x1B\x45\x00\n');
  const notes=[
    'Baju putih dicuci terpisah minimal 3 kg.',
    'Kami tidak menerima komplain lebih dari 2x24jam setelah customer menerima Laundry.',
    'Baju yang mudah luntur TAPI tidak memberitahu kami sebelumnya, bukan tanggung jawab kami.',
    'Di sarankan baju luntur untuk cuci satuan.',
    'Jika ingin pakaian Bapak/Ibu dikerjakan lebih optimal disarankan untuk pengerjaan satuan.',
    'Laundry yang lebih dari 10 hari tidak diambil bukan menjadi tanggung jawab kami.',
    'Laundry anda GRATIS apabila tidak mendapatkan nota.'
  ];
  notes.forEach((n,idx)=>{wrapReceipt(n,30).forEach((line,j)=>push((j===0?'- ':'  ')+line+'\n'));if(idx===2)push('\n')});
  push('\nKritik dan saran\n0856930280500\n\n#Terimakasih Kasih#\n\n\n\n');
  push('\x1D\x56\x00');

  const payload=new Uint8Array(bytes.length);payload.set(bytes);
  const chunk=180;
  try{
    for(let i=0;i<payload.length;i+=chunk){
      if(!printer?.gatt?.connected||!printerCharacteristic) throw new Error('Koneksi thermal printer terputus.');
      const part=payload.slice(i,i+chunk);
      if(printerCharacteristic.writeValueWithoutResponse) await printerCharacteristic.writeValueWithoutResponse(part);
      else await printerCharacteristic.writeValue(part);
      await new Promise(r=>setTimeout(r,20));
    }
    return true;
  }catch(err){
    printer=null;printerCharacteristic=null;onPrinterDisconnected();
    throw new Error('Cetak gagal karena koneksi printer terputus. Hubungkan kembali thermal printer lalu cetak ulang.');
  }
}
function setupNumpad(){const pad=[1,2,3,4,5,6,7,8,9,'.',0,'⌫'];$('numpad').innerHTML=pad.map(x=>`<button type="button" onclick="numKey('${x}')">${x}</button>`).join('');document.removeEventListener('focusin',handleNumFocus);document.addEventListener('focusin',handleNumFocus)}
function handleNumFocus(e){if(e.target?.classList?.contains('num-input'))openNumpad(e.target)}
function openNumpad(el){numTarget=el;$('numDisplay').textContent=el.value||'0';$('numpadModal').classList.add('show');setTimeout(()=>el.blur(),0)}function numKey(k){if(!numTarget)return;let v=numTarget.value||'';if(k==='⌫')v=v.slice(0,-1);else if(k==='.'&&!v.includes('.'))v+='.';else if(k!=='.')v+=k;numTarget.value=v;$('numDisplay').textContent=v||'0';numTarget.dispatchEvent(new Event('input',{bubbles:true}))}
if($('e-tanggal'))$('e-tanggal').value=new Date().toISOString().slice(0,10);addPackage();setupNumpad();restorePrinter();loadDashboard(true);loadDeadline();showTab('ops');
